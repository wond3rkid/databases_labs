<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=university', 'root', '1326');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->query('SELECT * FROM students');
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo 'Ошибка: ' . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=3.0">
    <title>Список студентов</title>
</head>
<body>
<h1>Список студентов</h1>
<table border="1">
    <tr>
        <th>Номер</th>
        <th>Имя</th>
        <th>Фамилия</th>
        <th>Отчество</th>
        <th>GPA</th>
        <th>ID группы</th>
        <th>Email</th>
        <th>Телефон</th>
        <th>Дата рождения</th>
    </tr>
    <?php foreach ($students as $student): ?>
        <tr>
            <td><?= htmlspecialchars($student['id']); ?></td>
            <td><?= htmlspecialchars($student['first_name']); ?></td>
            <td><?= htmlspecialchars($student['last_name']); ?></td>
            <td><?= htmlspecialchars($student['patronymic']); ?></td>
            <td><?= htmlspecialchars($student['gpa']); ?></td>
            <td><?= htmlspecialchars($student['group_id']); ?></td>
            <td><?= htmlspecialchars($student['email']); ?></td>
            <td><?= htmlspecialchars($student['phone_number']); ?></td>
            <td><?= htmlspecialchars($student['birth_date']); ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<a href="index.php">Назад на главную</a>
</body>
</html>
